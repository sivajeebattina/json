//
//  AboutObject.h
//  JsonParsing
//
//  Created by pcs20 on 9/18/14.
//  Copyright (c) 2014 Paradigmcreatives. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AboutObject : NSObject

@property(nonatomic,strong)NSString *about;

@end
